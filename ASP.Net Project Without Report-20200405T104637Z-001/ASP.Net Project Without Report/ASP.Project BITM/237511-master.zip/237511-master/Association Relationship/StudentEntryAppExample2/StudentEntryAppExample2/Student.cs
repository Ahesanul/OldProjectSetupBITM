﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentEntryAppExample2
{
    public class Student
    {
        public string RegNo { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

    }
}
