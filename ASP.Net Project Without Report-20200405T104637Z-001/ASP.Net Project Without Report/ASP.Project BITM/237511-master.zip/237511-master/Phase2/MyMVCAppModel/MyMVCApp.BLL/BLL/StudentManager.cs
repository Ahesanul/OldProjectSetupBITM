﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataBaseContext.DataBaseContext;
using MyMVCApp.Repository.Repository;

namespace MyMVCApp.BLL.BLL
{
    public class StudentManager
    {
        StudentRepository _studentRepository = new StudentRepository();
        public bool Add(Student student)
        {
            return _studentRepository.Add(student);
        }
        public bool Delete(Student student)
        {
            return _studentRepository.Delete(student);
        }
        public bool Update(Student student)
        {
            return _studentRepository.Update(student);
        }
        public List<Student> GetAll(Student student)
        {

            return _studentRepository.GetAll(student).ToList();
        }
        public Student GetByID(Student student)
        {
            return _studentRepository.GetByID(student);
        }
    }
}
