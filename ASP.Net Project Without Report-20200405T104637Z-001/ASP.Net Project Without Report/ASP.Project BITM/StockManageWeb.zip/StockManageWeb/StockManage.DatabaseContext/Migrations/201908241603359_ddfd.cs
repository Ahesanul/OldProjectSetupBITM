﻿namespace StockManage.DatabaseContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ddfd : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.OrderRemarks",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        PurchaseID = c.Int(nullable: false),
                        Date = c.DateTime(nullable: false),
                        Discription = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.OrderRemarks");
        }
    }
}
