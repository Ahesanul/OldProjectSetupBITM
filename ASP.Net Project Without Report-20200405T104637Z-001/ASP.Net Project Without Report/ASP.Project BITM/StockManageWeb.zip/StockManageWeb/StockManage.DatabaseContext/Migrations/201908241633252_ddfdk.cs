﻿namespace StockManage.DatabaseContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ddfdk : DbMigration
    {
        public override void Up()
        {
            CreateIndex("dbo.OrderRemarks", "PurchaseID");
            AddForeignKey("dbo.OrderRemarks", "PurchaseID", "dbo.Purchases", "ID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.OrderRemarks", "PurchaseID", "dbo.Purchases");
            DropIndex("dbo.OrderRemarks", new[] { "PurchaseID" });
        }
    }
}
