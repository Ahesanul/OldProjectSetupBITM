﻿namespace StockManage.DatabaseContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class asd : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.OrderRemarks", "PurchaseID", "dbo.Purchases");
            DropIndex("dbo.OrderRemarks", new[] { "PurchaseID" });
            AddColumn("dbo.OrderRemarks", "ProductID", c => c.Int(nullable: false));
            CreateIndex("dbo.OrderRemarks", "ProductID");
            AddForeignKey("dbo.OrderRemarks", "ProductID", "dbo.Products", "ID", cascadeDelete: true);
            DropColumn("dbo.OrderRemarks", "PurchaseID");
        }
        
        public override void Down()
        {
            AddColumn("dbo.OrderRemarks", "PurchaseID", c => c.Int(nullable: false));
            DropForeignKey("dbo.OrderRemarks", "ProductID", "dbo.Products");
            DropIndex("dbo.OrderRemarks", new[] { "ProductID" });
            DropColumn("dbo.OrderRemarks", "ProductID");
            CreateIndex("dbo.OrderRemarks", "PurchaseID");
            AddForeignKey("dbo.OrderRemarks", "PurchaseID", "dbo.Purchases", "ID", cascadeDelete: true);
        }
    }
}
