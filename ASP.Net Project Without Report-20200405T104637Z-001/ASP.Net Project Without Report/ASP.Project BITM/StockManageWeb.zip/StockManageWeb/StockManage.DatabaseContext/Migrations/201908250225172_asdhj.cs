﻿namespace StockManage.DatabaseContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class asdhj : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.OrderRemarks", "ProductID", "dbo.Products");
            DropIndex("dbo.OrderRemarks", new[] { "ProductID" });
            AddColumn("dbo.OrderRemarks", "PurchaseID", c => c.Int(nullable: false));
            CreateIndex("dbo.OrderRemarks", "PurchaseID");
            AddForeignKey("dbo.OrderRemarks", "PurchaseID", "dbo.Purchases", "ID", cascadeDelete: true);
            DropColumn("dbo.OrderRemarks", "ProductID");
        }
        
        public override void Down()
        {
            AddColumn("dbo.OrderRemarks", "ProductID", c => c.Int(nullable: false));
            DropForeignKey("dbo.OrderRemarks", "PurchaseID", "dbo.Purchases");
            DropIndex("dbo.OrderRemarks", new[] { "PurchaseID" });
            DropColumn("dbo.OrderRemarks", "PurchaseID");
            CreateIndex("dbo.OrderRemarks", "ProductID");
            AddForeignKey("dbo.OrderRemarks", "ProductID", "dbo.Products", "ID", cascadeDelete: true);
        }
    }
}
