﻿namespace StockManage.DatabaseContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class fasfl : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Products", "Product_ID", "dbo.Products");
            DropIndex("dbo.Products", new[] { "Product_ID" });
            DropColumn("dbo.Products", "Product_ID");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Products", "Product_ID", c => c.Int());
            CreateIndex("dbo.Products", "Product_ID");
            AddForeignKey("dbo.Products", "Product_ID", "dbo.Products", "ID");
        }
    }
}
